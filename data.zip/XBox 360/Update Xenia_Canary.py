import requests
import os
import zipfile
import shutil

def safe_print(text):
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode('ascii', errors='ignore').decode())

# Get the directory path of the script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Path to save current version info
version_file_path = os.path.join(current_dir, "Xenia_Canary", "version.txt")

def get_installed_version():
    if os.path.exists(version_file_path):
        with open(version_file_path, 'r') as f:
            return f.read().strip()
    return None

def save_version(version):
    os.makedirs(os.path.dirname(version_file_path), exist_ok=True)
    with open(version_file_path, 'w') as f:
        f.write(version)

# GitHub API for latest release of Xenia Canary
release_api_url = "https://api.github.com/repos/xenia-canary/xenia-canary-releases/releases/latest"

try:
    response = requests.get(release_api_url)
    if response.status_code == 200:
        safe_print("🌐 Successfully fetched latest release info.")
        data = response.json()

        latest_version = data.get('tag_name') or data.get('name')
        if not latest_version:
            safe_print("⚠️ Could not determine latest version from release info.")
            latest_version = "unknown"

        installed_version = get_installed_version()
        safe_print(f"ℹ️ Installed version: {installed_version}")
        safe_print(f"ℹ️ Latest version: {latest_version}")

        if installed_version == latest_version:
            safe_print("✅ Xenia Canary is already up to date.")
        else:
            if 'assets' in data and len(data['assets']) > 0:
                windows_assets = [
                    asset for asset in data['assets']
                    if asset['name'].endswith('.zip') and 'windows' in asset['name'].lower()
                ]

                if windows_assets:
                    asset = windows_assets[0]
                    download_url = asset['browser_download_url']
                    file_name = asset['name']
                    download_path = os.path.join(current_dir, file_name)

                    safe_print(f"⬇️ Downloading: {download_url}")
                    file_response = requests.get(download_url)
                    if file_response.status_code == 200:
                        with open(download_path, 'wb') as f:
                            f.write(file_response.content)
                        safe_print(f"✅ Downloaded: {file_name}")

                        # Extract to temp
                        temp_dir = os.path.join(current_dir, "xenia_canary_temp")
                        os.makedirs(temp_dir, exist_ok=True)

                        with zipfile.ZipFile(download_path, 'r') as zip_ref:
                            zip_ref.extractall(temp_dir)
                        safe_print(f"📂 Extracted to temp dir: {temp_dir}")

                        # Final target dir
                        dest_dir = os.path.join(current_dir, "Xenia_Canary")
                        os.makedirs(dest_dir, exist_ok=True)

                        # Copy extracted files to destination, updating existing files
                        for root, dirs, files in os.walk(temp_dir):
                            rel_path = os.path.relpath(root, temp_dir)
                            dest_path = os.path.join(dest_dir, rel_path)
                            os.makedirs(dest_path, exist_ok=True)
                            for file in files:
                                shutil.copy2(os.path.join(root, file), os.path.join(dest_path, file))

                        # Save new version
                        save_version(latest_version)

                        # Clean up
                        shutil.rmtree(temp_dir)
                        os.remove(download_path)
                        safe_print("🧹 Cleanup done. Latest Xenia Canary is ready.")
                    else:
                        safe_print(f"❌ Download failed: {file_response.status_code}")
                else:
                    safe_print("⚠️ No suitable Windows ZIP file found in assets.")
            else:
                safe_print("⚠️ No assets found in latest release.")
    else:
        safe_print(f"❌ Failed to fetch release data: {response.status_code}")
except requests.RequestException as e:
    safe_print(f"⚠️ Request error: {e}")
