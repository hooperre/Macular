import os
import subprocess

# Force script to run from its own folder
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# ========== CONFIGURATION SECTION ==========
emulators = {
    "Gamecube + Wii": {
        "Dolphin": {
            "enabled": True,
            "updater_path": "./Gamecube + Wii/Update Dolphin.py"
        }
    },
    "Nintendo 3DS": {
        "AzaharPlus": {
            "enabled": True,
            "updater_path": "./Nintendo 3DS/Update AzaharPlus.py"
        }
    },
    "PS3": {
        "RPCS3": {
            "enabled": True,
            "updater_path": "./PS3/Update RPCS3.bat"
        }
    },
    "PS2": {
        "PCSX2": {
            "enabled": True,
            "updater_path": "./PS2/Update PCSX2 Nightly.py"
        }
    },    
    "PS4": {
        "ShadPS4": {
            "enabled": True,
            "updater_path": "./PS4/Update ShadPS4.py"
        }
    },
    "PSVita": {
        "Vita3K": {
            "enabled": True,
            "updater_path": "./PSVita/Update Vita3K.py"
        }
    },
    "PSX": {
        "Duckstation": {
            "enabled": True,
            "updater_path": "./PSX/Update Duckstation.py"
        }
    },
    "Switch": {
        "Eden": {
            "enabled": True,
            "updater_path": "./Switch/Update Eden.py"
        }
    },
    "WiiU": {
        "Cemu": {
            "enabled": True,
            "updater_path": "./WiiU/Update Cemu.py"
        }
},
    "Xbox": {
        "XEMU": {
            "enabled": True,
            "updater_path": "./Xbox/Update XEMU.py"
        }
},
     "Xbox 360": {
        "Xenia Canary": {
            "enabled": True,
            "updater_path": "./Xbox 360/Update Xenia_Canary.py"
        }
    }
}
# ============================================


def run_updater(system, emulator, relative_path):
    abs_path = os.path.abspath(relative_path)
    working_dir = os.path.dirname(abs_path)
    is_batch = abs_path.lower().endswith('.bat')
    label = f"{emulator} ({system})"

    print(f"\n=== Updating {label} ===")
    print(f"▶ Running {'batch' if is_batch else 'Python'} script: {abs_path}")
    print("----- START -----")

    try:
        result = subprocess.run(
            abs_path if is_batch else ["python", abs_path],
            shell=is_batch,
            text=True,
            capture_output=True,
            cwd=working_dir
        )

        if result.stdout:
            print(result.stdout.strip())
        if result.stderr:
            print(result.stderr.strip())

        if result.returncode == 0:
            print("------ END ------")
            print(f"✅ {emulator} updater finished successfully.")
        else:
            print("------ END ------")
            print(f"⚠️ {emulator} updater finished with errors (exit code {result.returncode}).")

    except Exception as e:
        print("------ END ------")
        print(f"❌ Failed to run {label} updater: {e}")

def main():
    print("========== Emulator Updater ==========")
    for system, emulators_dict in emulators.items():
        for emulator, config in emulators_dict.items():
            if config["enabled"]:
                run_updater(system, emulator, config["updater_path"])

    print("\nAll done. Press Enter to exit...")
    input()

if __name__ == "__main__":
    main()
