import requests
import os
import shutil
import py7zr
from bs4 import BeautifulSoup

current_dir = os.path.dirname(os.path.abspath(__file__))
dolphin_dir = os.path.join(current_dir, 'Dolphin')
os.makedirs(dolphin_dir, exist_ok=True)

version_file = os.path.join(dolphin_dir, 'version.txt')
dolphin_download_url = 'https://dolphin-emu.org/download/'

def read_version():
    if os.path.exists(version_file):
        with open(version_file, 'r') as f:
            return f.read().strip()
    return None

def write_version(ver):
    with open(version_file, 'w') as f:
        f.write(ver)

def get_latest_build_link():
    response = requests.get(dolphin_download_url)
    if response.status_code != 200:
        print("Failed to fetch the Dolphin download page")
        return None, None

    soup = BeautifulSoup(response.content, 'html.parser')

    for link in soup.find_all('a'):
        href = link.get('href')
        if href and 'dolphin' in href and href.endswith('-x64.7z'):
            filename = href.split('/')[-1]
            version = filename.split('-x64')[0]
            return href, version
    print("No valid Dolphin emulator build found on the webpage.")
    return None, None

def download_file(url, path):
    print(f"Downloading {url} to {path} ...")
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            shutil.copyfileobj(r.raw, f)
    print("Download completed.")

def extract_and_copy(src_7z, dest_folder):
    temp_dir = os.path.join(dest_folder, 'temp_extract')
    os.makedirs(temp_dir, exist_ok=True)

    with py7zr.SevenZipFile(src_7z, mode='r') as archive:
        archive.extractall(temp_dir)

    dolphin_src = os.path.join(temp_dir, 'Dolphin-x64')
    if not os.path.exists(dolphin_src):
        print("No 'Dolphin-x64' folder found inside the archive.")
        shutil.rmtree(temp_dir)
        return False

    for root, dirs, files in os.walk(dolphin_src):
        for file in files:
            src_file = os.path.join(root, file)
            relative_path = os.path.relpath(src_file, dolphin_src)
            dest_file = os.path.join(dest_folder, relative_path)
            os.makedirs(os.path.dirname(dest_file), exist_ok=True)
            shutil.copy2(src_file, dest_file)

    shutil.rmtree(temp_dir)
    return True

def main():
    current_version = read_version()
    print(f"Current Dolphin version: {current_version or 'None'}")

    latest_url, latest_version = get_latest_build_link()
    if latest_url is None:
        return

    if current_version == latest_version:
        print("Dolphin is already up to date.")
        return

    print(f"Updating Dolphin from {current_version} to {latest_version}")

    download_path = os.path.join(current_dir, latest_url.split('/')[-1])
    try:
        download_file(latest_url, download_path)
        if extract_and_copy(download_path, dolphin_dir):
            write_version(latest_version)
            print(f"Dolphin updated to version {latest_version}")
        else:
            print("Failed to extract and update Dolphin files.")
    except Exception as e:
        print(f"Error during update: {e}")
    finally:
        if os.path.exists(download_path):
            os.remove(download_path)

if __name__ == "__main__":
    main()
