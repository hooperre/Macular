import requests
import os
import zipfile
import shutil
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
release_url = 'https://api.github.com/repos/cemu-project/Cemu/releases'

def get_latest_release():
    try:
        print("Fetching latest Cemu release info...")
        response = requests.get(release_url)
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        print(f"Error fetching release info: {e}")
        return None, None

    for release in data:
        assets = release.get('assets', [])
        windows_assets = [
            asset['browser_download_url'] for asset in assets
            if 'windows-x64' in asset['name'].lower() and asset['name'].endswith('.zip')
        ]
        if windows_assets:
            version = release.get('tag_name') or release.get('name') or 'unknown-version'
            return version, windows_assets[0]

    print("No valid Windows ZIP asset found in releases.")
    return None, None

def main():
    version, download_url = get_latest_release()
    if not version or not download_url:
        print("Could not get latest release info.")
        return

    version_file_path = os.path.join(current_dir, "Cemu", "version.txt")
    current_version = None
    if os.path.exists(version_file_path):
        with open(version_file_path, "r", encoding="utf-8") as vf:
            current_version = vf.read().strip()

    if current_version == version:
        print(f"Cemu is already up to date (version {current_version}). No update needed.")
        return

    print(f"Updating Cemu from version {current_version or 'none'} to {version}")

    file_name = download_url.split('/')[-1]
    download_path = os.path.join(current_dir, file_name)

    try:
        print(f"Downloading {download_url} ...")
        file_response = requests.get(download_url)
        file_response.raise_for_status()
        with open(download_path, 'wb') as f:
            f.write(file_response.content)
        print(f"Downloaded to {download_path}")
    except Exception as e:
        print(f"Download failed: {e}")
        return

    temp_dir = os.path.join(current_dir, 'cemu-temp')
    try:
        os.makedirs(temp_dir, exist_ok=True)
        with zipfile.ZipFile(download_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except Exception as e:
        print(f"Failed to extract ZIP: {e}")
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        if os.path.exists(download_path):
            os.remove(download_path)
        return

    version_dir = None
    try:
        for item in os.listdir(temp_dir):
            path = os.path.join(temp_dir, item)
            if os.path.isdir(path):
                version_dir = path
                break

        if not version_dir:
            print("Version-specific folder not found in extracted contents.")
            shutil.rmtree(temp_dir)
            os.remove(download_path)
            return

        dest_dir = os.path.join(current_dir, 'Cemu')
        os.makedirs(dest_dir, exist_ok=True)

        # Copy all files & folders from version_dir into dest_dir, updating existing files
        for root, dirs, files in os.walk(version_dir):
            rel_path = os.path.relpath(root, version_dir)
            dest_root = os.path.join(dest_dir, rel_path)
            os.makedirs(dest_root, exist_ok=True)
            for file in files:
                shutil.copy2(os.path.join(root, file), os.path.join(dest_root, file))

        # Write new version
        with open(version_file_path, 'w', encoding='utf-8') as vf:
            vf.write(version)

        print(f"Cemu updated to version {version} successfully.")
    except Exception as e:
        print(f"Error during file operations: {e}")
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        if os.path.exists(download_path):
            os.remove(download_path)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)
