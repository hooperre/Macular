import os
import sys
import json
import shutil
import urllib.request
from zipfile import ZipFile

def log(msg):
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        fallback_msg = msg.encode('ascii', errors='replace').decode('ascii')
        print(fallback_msg, flush=True)

def main():
    try:
        log("Fetching latest Vita3K release info...")

        url = "https://api.github.com/repos/vita3k/vita3k/releases/latest"
        with urllib.request.urlopen(url) as response:
            data = json.load(response)

        assets = data.get("assets", [])
        zip_asset = None
        for asset in assets:
            if asset["name"].endswith("windows.zip"):
                zip_asset = asset
                break

        if not zip_asset:
            log("Could not find a suitable windows.zip asset.")
            log("Vita3K updater failed.")
            return

        download_url = zip_asset["browser_download_url"]
        version_id = data.get("id", "unknown")

        log(f"Downloading Vita3K version {version_id}...")

        dest_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vita3k")
        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)

        zip_path = os.path.join(dest_folder, "vita3k-windows.zip")

        urllib.request.urlretrieve(download_url, zip_path)
        log("Download complete.")

        # Extract
        with ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(dest_folder)

        os.remove(zip_path)

        # Save version file
        version_file = os.path.join(dest_folder, "version.txt")
        with open(version_file, "w") as vf:
            vf.write(str(version_id))

        log(f"Vita3K updated to version {version_id} successfully.")

    except Exception as e:
        log(f"Update failed: {e}")

if __name__ == "__main__":
    main()

