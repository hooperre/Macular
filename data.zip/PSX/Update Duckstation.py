import os
import requests
import zipfile
import shutil

# ========== Configuration ==========
GITHUB_API = "https://api.github.com/repos/stenzek/duckstation/releases/latest"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DUCKSTATION_DIR = os.path.join(SCRIPT_DIR, "Duckstation")
VERSION_FILE = os.path.join(DUCKSTATION_DIR, "version.txt")
TEMP_ZIP_PATH = os.path.join(SCRIPT_DIR, "duckstation-latest.zip")
# ===================================

def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        sanitized = [str(a).encode('ascii', errors='ignore').decode() for a in args]
        print(*sanitized, **kwargs)

def get_latest_release():
    response = requests.get(GITHUB_API)
    response.raise_for_status()
    data = response.json()

    release_id = str(data.get("id", "unknown"))
    asset = next(
        (a for a in data.get("assets", [])
         if a["name"].endswith("x64-release.zip") and "windows" in a["name"].lower() and "release" in a["name"].lower()),
        None
    )

    if not asset:
        raise RuntimeError("Could not find a suitable Windows release asset.")
    
    return release_id, asset["browser_download_url"], asset["name"]

def read_installed_version():
    if os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None

def write_version(version):
    os.makedirs(DUCKSTATION_DIR, exist_ok=True)
    with open(VERSION_FILE, "w", encoding="utf-8") as f:
        f.write(version)

def extract_zip(zip_path, destination):
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(destination)

def main():
    safe_print("Fetching latest DuckStation release info...")

    try:
        latest_version, download_url, filename = get_latest_release()
        current_version = read_installed_version()

        if current_version == latest_version:
            safe_print(f"DuckStation is already up to date (version {current_version}).")
            return

        safe_print(f"⬇️ Downloading {filename} ...")
        r = requests.get(download_url)
        r.raise_for_status()
        with open(TEMP_ZIP_PATH, "wb") as f:
            f.write(r.content)
        safe_print(f"Downloaded to {TEMP_ZIP_PATH}")

        os.makedirs(DUCKSTATION_DIR, exist_ok=True)
        extract_zip(TEMP_ZIP_PATH, DUCKSTATION_DIR)
        write_version(latest_version)

        os.remove(TEMP_ZIP_PATH)
        safe_print(f"✅ DuckStation updated to version ID {latest_version}.")

    except Exception as e:
        safe_print(f"❌ DuckStation updater failed: {e}")

    input("Press Enter to exit...")

if __name__ == "__main__":
    main()
