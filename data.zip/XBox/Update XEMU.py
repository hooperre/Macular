import os
import requests
import zipfile
import shutil

# ========== Configuration ==========
api_url = "https://api.github.com/repos/xemu-project/xemu/releases/latest"
version_file = os.path.join(os.path.dirname(__file__), "Xemu", "version.txt")
extract_dir = os.path.join(os.path.dirname(__file__), "Xemu")
temp_zip_path = os.path.join(os.path.dirname(__file__), "xemu-latest.zip")
# ===================================

def safe_print(*args, **kwargs):
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        sanitized = [str(a).encode('ascii', errors='ignore').decode() for a in args]
        print(*sanitized, **kwargs)

def get_latest_release_info():
    safe_print("🌐 Fetching latest Xemu release info...")
    response = requests.get(api_url)
    response.raise_for_status()
    data = response.json()
    version = data.get("tag_name") or data.get("name")
    download_url = None

    for asset in data.get("assets", []):
        if asset["name"] == "xemu-win-release.zip":
            download_url = asset["browser_download_url"]
            break

    if not download_url:
        raise RuntimeError("Could not find xemu-win-release.zip in the latest release.")

    return version.strip(), download_url

def read_installed_version():
    if os.path.exists(version_file):
        with open(version_file, "r") as f:
            return f.read().strip()
    return None

def write_version(version):
    os.makedirs(os.path.dirname(version_file), exist_ok=True)
    with open(version_file, "w") as f:
        f.write(version)

def extract_zip(zip_path, destination):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(destination)

def update_xemu():
    try:
        version, download_url = get_latest_release_info()
        current_version = read_installed_version()

        if current_version == version:
            safe_print(f"Xemu is already up to date (version {version}).")
            return

        safe_print(f"Updating Xemu from version {current_version or 'none'} to {version}")
        safe_print(f"⬇️ Downloading: {download_url}")
        r = requests.get(download_url)
        r.raise_for_status()
        with open(temp_zip_path, "wb") as f:
            f.write(r.content)

        # Extract to target folder (non-destructive)
        os.makedirs(extract_dir, exist_ok=True)
        extract_zip(temp_zip_path, extract_dir)

        # Save version
        write_version(version)

        # Clean up
        os.remove(temp_zip_path)

        safe_print(f"✅ Xemu updated to version {version} successfully.")

    except Exception as e:
        safe_print(f"❌ Update failed: {e}")

def main():
    update_xemu()

if __name__ == "__main__":
    main()
