import os
import requests
import shutil
import zipfile
import tempfile
import filecmp

def copy_updated_files(src_dir, dest_dir):
    for root, dirs, files in os.walk(src_dir):
        rel_path = os.path.relpath(root, src_dir)
        dest_root = os.path.join(dest_dir, rel_path)
        os.makedirs(dest_root, exist_ok=True)

        for file in files:
            src_file = os.path.join(root, file)
            dest_file = os.path.join(dest_root, file)

            # Copy if file doesn't exist or differs
            if not os.path.exists(dest_file) or not filecmp.cmp(src_file, dest_file, shallow=False):
                shutil.copy2(src_file, dest_file)

def extract_zip_flat(src_zip, dest_folder):
    # Extract zip to a temporary directory
    with tempfile.TemporaryDirectory() as temp_dir:
        with zipfile.ZipFile(src_zip, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)

        root_items = os.listdir(temp_dir)
        # If a single root folder inside zip, copy its contents to dest_folder
        if len(root_items) == 1 and os.path.isdir(os.path.join(temp_dir, root_items[0])):
            root_folder = os.path.join(temp_dir, root_items[0])
            copy_updated_files(root_folder, dest_folder)
        else:
            # Multiple root items, copy all contents
            copy_updated_files(temp_dir, dest_folder)

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    azahar_dir = os.path.join(current_dir, 'AzaharPlus')
    os.makedirs(azahar_dir, exist_ok=True)

    api_url = 'https://api.github.com/repos/AzaharPlus/AzaharPlus/releases/latest'

    print("Fetching latest release info from GitHub...")
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        release_info = response.json()

        asset = None
        for a in release_info.get('assets', []):
            name = a.get('name', '')
            if name.endswith('-windows.zip') and 'azaharplus' in name.lower():
                asset = a
                break

        if not asset:
            print("No suitable Windows download asset found.")
            input("Press Enter to exit...")
            return

        latest_version = asset['name'].split('-')[1]
        print(f"Latest version detected: {latest_version}")

        version_file = os.path.join(azahar_dir, 'version.txt')
        current_version = None
        if os.path.exists(version_file):
            with open(version_file, 'r') as vf:
                current_version = vf.read().strip()

        if current_version == latest_version:
            print(f"AzaharPlus is already up to date (version {current_version}). No update needed.")
            return

        download_url = asset['browser_download_url']
        zip_path = os.path.join(current_dir, asset['name'])

        print(f"Downloading {asset['name']}...")
        with requests.get(download_url, stream=True) as r:
            r.raise_for_status()
            with open(zip_path, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
        print("Download complete.")

        print("Extracting files...")
        extract_zip_flat(zip_path, azahar_dir)
        print(f"Extraction complete to: {azahar_dir}")

        with open(version_file, 'w') as vf:
            vf.write(latest_version)
        print(f"Updated version.txt with version {latest_version}")

        os.remove(zip_path)
        print("Cleaned up downloaded zip file.")

    except Exception as e:
        print(f"Error occurred: {e}")
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()
