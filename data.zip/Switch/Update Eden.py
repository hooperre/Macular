import os
import io
import sys
import json
import zipfile
import urllib.request

def log(msg):
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        print(msg.encode('ascii', errors='ignore').decode(), flush=True)

def get_latest_release_info():
    url = "https://api.github.com/repos/eden-emulator/Releases/releases/latest"
    with urllib.request.urlopen(url) as response:
        data = response.read()
    return json.loads(data)

def main():
    try:
        # Get the directory where this script resides
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        log("🌐 Fetching latest Eden release info...")
        release_info = get_latest_release_info()
        assets = release_info.get("assets", [])
        target_asset = None
        version_str = None

        for asset in assets:
            name = asset.get("name", "")
            if name.startswith("Eden-Windows-MSVC-") and name.endswith("-amd64.zip"):
                log(f"Checking asset: {name}")
                target_asset = asset
                parts = name.split("-")
                if len(parts) >= 5:
                    version_str = parts[3]
                break

        if not target_asset:
            log("❌ Could not find suitable Eden Windows asset.")
            return

        if not version_str:
            log("❌ Could not parse version from asset name.")
            return

        extract_path = os.path.join(script_dir, "Eden")
        version_file = os.path.join(extract_path, "version.txt")

        # Check existing version
        if os.path.exists(version_file):
            with open(version_file, "r", encoding="utf-8") as vf:
                current_version = vf.read().strip()
            if current_version == version_str:
                log(f"✅ Eden is already up to date (version {version_str}). Skipping download.")
                return

        log(f"📥 Downloading {target_asset['name']} ...")
        download_url = target_asset["browser_download_url"]

        with urllib.request.urlopen(download_url) as response:
            data = response.read()

        if not os.path.exists(extract_path):
            os.makedirs(extract_path)

        log(f"📦 Extracting {target_asset['name']} ...")
        with zipfile.ZipFile(io.BytesIO(data)) as zip_ref:
            zip_ref.extractall(extract_path)

        with open(version_file, "w", encoding="utf-8") as vf:
            vf.write(version_str)

        log(f"✅ Eden updated to version {version_str}.")

    except Exception as e:
        log(f"❌ Update failed: {e}")

if __name__ == "__main__":
    main()