import requests
import os
import zipfile
import shutil
import sys

# --- Configuration ---
REPO_API_URL = 'https://api.github.com/repos/shadps4-emu/shadPS4/releases'
TARGET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ShadPS4')
VERSION_FILE = os.path.join(TARGET_DIR, 'version.txt')
TEMP_DIR = os.path.join(os.path.dirname(TARGET_DIR), 'shadPS4-temp')

def print_header():
    print("Starting ShadPS4 update check...")

def get_latest_prerelease():
    print("Fetching latest ShadPS4 prerelease info from GitHub...")
    response = requests.get(REPO_API_URL)
    if response.status_code != 200:
        raise RuntimeError(f"GitHub API request failed. Status code: {response.status_code}")
    
    releases = response.json()
    pre_releases = [r for r in releases if r.get("prerelease")]
    if not pre_releases:
        raise RuntimeError("No prereleases found.")

    latest = pre_releases[0]
    version = latest["tag_name"]
    print(f"Latest prerelease: {version}")
    return latest, version

def get_download_url(release):
    for asset in release.get("assets", []):
        name = asset["name"]
        if "win64-qt" in name and name.endswith(".zip"):
            print(f"Found suitable asset: {name}")
            return asset["browser_download_url"], name
    raise RuntimeError("No suitable Windows 64-bit asset found.")

def read_local_version():
    if os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, 'r') as f:
            return f.read().strip()
    return None

def save_local_version(version):
    os.makedirs(TARGET_DIR, exist_ok=True)
    with open(VERSION_FILE, 'w') as f:
        f.write(version)

def download_zip(url, path):
    print(f"Downloading: {url}")
    response = requests.get(url)
    if response.status_code != 200:
        raise RuntimeError(f"Download failed with status code {response.status_code}")
    with open(path, 'wb') as f:
        f.write(response.content)
    print(f"Downloaded to: {path}")

def extract_zip(zip_path, extract_to):
    print(f"Extracting to: {extract_to}")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)

def move_files(src, dst):
    print(f"Moving extracted files to: {dst}")
    for root, _, files in os.walk(src):
        for file in files:
            src_file = os.path.join(root, file)
            dst_file = os.path.join(dst, file)
            shutil.copy2(src_file, dst_file)

def clean_temp(temp_path, zip_path):
    if os.path.exists(temp_path):
        shutil.rmtree(temp_path)
        print("Cleaned up temporary folder.")
    if os.path.exists(zip_path):
        os.remove(zip_path)
        print("Removed ZIP file.")

def main():
    try:
        print_header()
        release, latest_version = get_latest_prerelease()
        local_version = read_local_version()
        
        if local_version == latest_version:
            print("ShadPS4 is already up to date.")
            return

        download_url, filename = get_download_url(release)
        zip_path = os.path.join(os.path.dirname(__file__), filename)

        # Ensure clean state
        if os.path.exists(TEMP_DIR):
            shutil.rmtree(TEMP_DIR)
        os.makedirs(TEMP_DIR, exist_ok=True)

        # Download and extract
        download_zip(download_url, zip_path)
        extract_zip(zip_path, TEMP_DIR)
        os.makedirs(TARGET_DIR, exist_ok=True)
        move_files(TEMP_DIR, TARGET_DIR)

        # Save version
        save_local_version(latest_version)

        # Cleanup
        clean_temp(TEMP_DIR, zip_path)

        print("ShadPS4 updated successfully.")
    except Exception as e:
        print("\nFatal error:")
        print(e)

if __name__ == "__main__":
    main()
