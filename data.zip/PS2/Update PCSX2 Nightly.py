import os
import requests
import shutil
import py7zr

# Configuration
RELEASE_API_URL = "https://api.github.com/repos/PCSX2/pcsx2/releases"
EMULATOR_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "PCSX2")
VERSION_FILE = os.path.join(EMULATOR_DIR, "version.txt")

def get_latest_nightly_release():
    response = requests.get(RELEASE_API_URL)
    response.raise_for_status()
    releases = response.json()

    for release in releases:
        # Consider pre-releases as nightly builds
        if release.get("prerelease"):
            return release
    return None

def read_local_version():
    if os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, "r") as f:
            return f.read().strip()
    return None

def write_local_version(version):
    with open(VERSION_FILE, "w") as f:
        f.write(version)

def download_asset(url, dest_path):
    print(f"Downloading from {url} ...")
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(dest_path, "wb") as f:
            shutil.copyfileobj(r.raw, f)
    print(f"Downloaded to {dest_path}")

def extract_archive(archive_path, extract_to):
    print(f"Extracting archive to {extract_to} ...")
    with py7zr.SevenZipFile(archive_path, mode='r') as archive:
        archive.extractall(path=extract_to)
    print("Extraction complete.")

def copy_files(src_dir, dest_dir):
    for root, _, files in os.walk(src_dir):
        for file in files:
            src_file = os.path.join(root, file)
            relative_path = os.path.relpath(src_file, src_dir)
            dest_file = os.path.join(dest_dir, relative_path)
            os.makedirs(os.path.dirname(dest_file), exist_ok=True)
            shutil.copy2(src_file, dest_file)

def main():
    print("Fetching release info from GitHub...")
    release = get_latest_nightly_release()
    if not release:
        print("No nightly release found.")
        return

    latest_version = release.get("tag_name", "")
    print(f"Found nightly release: {latest_version}")

    local_version = read_local_version()
    print(f"Latest version: {latest_version}")
    print(f"Local version: {local_version if local_version else '(none)'}")

    if local_version == latest_version:
        print("PCSX2 is up to date.")
        return

    # Find correct asset (exclude symbols/debug builds)
    asset = None
    for a in release["assets"]:
        name = a["name"].lower()
        if (name.endswith(".7z") and
            "windows" in name and
            "x64" in name and
            "qt" in name and
            name.startswith("pcsx2-v") and
            "symbols" not in name and
            "debug" not in name):
            asset = a
            break

    if not asset:
        print("No suitable Windows x64 Qt release asset found.")
        return

    os.makedirs(EMULATOR_DIR, exist_ok=True)
    archive_path = os.path.join(EMULATOR_DIR, asset["name"])

    # Download the asset
    download_asset(asset["browser_download_url"], archive_path)

    # Extract archive to emulator dir
    extract_archive(archive_path, EMULATOR_DIR)

    # Clean up archive
    os.remove(archive_path)

    # Some builds extract into a subfolder named like pcsx2-v2.3.381-windows-x64-Qt
    # We want to move all extracted content *up* into EMULATOR_DIR root
    # Let's check if such a folder exists, then move its content up and delete it
    extracted_subfolder = None
    for entry in os.listdir(EMULATOR_DIR):
        full_path = os.path.join(EMULATOR_DIR, entry)
        if os.path.isdir(full_path) and entry.lower().startswith("pcsx2-v") and "windows" in entry.lower():
            extracted_subfolder = full_path
            break

    if extracted_subfolder:
        print(f"Moving files from extracted subfolder {extracted_subfolder} to {EMULATOR_DIR} ...")
        copy_files(extracted_subfolder, EMULATOR_DIR)
        shutil.rmtree(extracted_subfolder)

    # Write version file
    write_local_version(latest_version)

    print(f"PCSX2 updated to version {latest_version}!")


if __name__ == "__main__":
    main()
